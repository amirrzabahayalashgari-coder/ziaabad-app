package com.ziaai.persian

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.text.InputType
import android.text.Layout
import android.text.TextDirectionHeuristics
import android.text.StaticLayout
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import java.util.UUID
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("ziaai_secure", MODE_PRIVATE) }
    private var selectedUri: Uri? = null
    private var selectedFile: File? = null
    private var recorder: MediaRecorder? = null
    private var isRecording = false
    private var pendingBytes: ByteArray? = null
    private var pendingMime = "text/plain"
    private var pendingName = "transcript.txt"
    private lateinit var apiKeyInput: EditText
    private lateinit var hintInput: EditText
    private lateinit var transcriptInput: EditText
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var recordButton: Button

    companion object {
        private const val PICK_AUDIO = 1001
        private const val CREATE_EXPORT = 1002
        private const val REQUEST_MIC = 1003
        private const val GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
        private const val KEY_ALIAS = "ziaai_groq_key_v1"
        private const val MAX_FILE_BYTES = 100L * 1024L * 1024L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 25, 35)
        window.navigationBarColor = Color.rgb(16, 25, 35)
        buildUi()
        apiKeyInput.setText(loadApiKey())
        status("آماده؛ یک فایل صوتی انتخاب کن یا ضبط را شروع کن.")
    }

    private fun buildUi() {
        val bg = Color.rgb(16, 25, 35)
        val panel = Color.rgb(27, 41, 56)
        val mint = Color.rgb(101, 215, 194)
        val white = Color.rgb(241, 246, 250)
        val muted = Color.rgb(169, 184, 198)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(column)

        val brand = TextView(this).apply {
            text = "ZiaAI  |  فارسی"
            textSize = 28f; setTextColor(mint); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }
        column.addView(brand, matchWrap())
        val subtitle = TextView(this).apply {
            text = "تبدیل گفتار فارسی به متن با هوش مصنوعی"
            textSize = 14f; setTextColor(muted); gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, dp(20))
        }
        column.addView(subtitle, matchWrap())

        section(column, "۱. اتصال امن به موتور تشخیص گفتار", panel, white)
        apiKeyInput = EditText(this).apply {
            hint = "کلید API سرویس Groq را وارد کن"
            setHintTextColor(muted); setTextColor(white); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true); layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(38, 54, 70))
        }
        column.addView(apiKeyInput, margin(matchWrap(), bottom = 8))
        button(column, "ذخیره امن کلید روی گوشی", mint, bg) { saveApiKey() }
        val privacy = TextView(this).apply {
            text = "کلید در سورس و APK قرار نمی‌گیرد؛ روی دستگاه رمزگذاری می‌شود. فایل صوتی برای تبدیل به سرور Groq فرستاده خواهد شد و استفاده از API ممکن است هزینه داشته باشد."
            textSize = 12f; setTextColor(muted); gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, dp(18))
        }
        column.addView(privacy, matchWrap())

        section(column, "۲. انتخاب یا ضبط فایل صوتی", panel, white)
        button(column, "انتخاب فایل صوتی از گوشی", mint, bg) { pickAudio() }
        recordButton = button(column, "شروع ضبط با میکروفون", Color.rgb(54, 82, 99), white) { toggleRecording() }
        val limit = TextView(this).apply {
            text = "فرمت‌های رایج صوت پشتیبانی می‌شوند؛ حداکثر حجم هر فایل ۱۰۰ مگابایت است."
            textSize = 12f; setTextColor(muted); gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, dp(14))
        }
        column.addView(limit, matchWrap())

        section(column, "۳. واژه‌های راهنما (اختیاری)", panel, white)
        hintInput = EditText(this).apply {
            hint = "نام‌ها، اصطلاحات محلی یا واژه‌های تخصصی را بنویس…"
            setHintTextColor(muted); setTextColor(white); textSize = 14f
            minLines = 2; gravity = Gravity.TOP or Gravity.RIGHT
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(38, 54, 70))
        }
        column.addView(hintInput, margin(matchWrap(), bottom = 12))
        button(column, "شروع تبدیل گفتار فارسی", mint, bg) { transcribe() }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE; max = 100
        }
        column.addView(progress, margin(matchWrap(), top = 10, bottom = 8))
        statusText = TextView(this).apply {
            textSize = 13f; setTextColor(muted); gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(18))
        }
        column.addView(statusText, matchWrap())

        section(column, "۴. متن تشخیص‌داده‌شده و خروجی", panel, white)
        transcriptInput = EditText(this).apply {
            hint = "متن فارسی اینجا نمایش داده می‌شود…"
            setHintTextColor(muted); setTextColor(white); textSize = 16f
            minLines = 7; gravity = Gravity.TOP or Gravity.RIGHT
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(27, 41, 56))
        }
        column.addView(transcriptInput, margin(matchWrap(), bottom = 10))
        button(column, "کپی متن", Color.rgb(54, 82, 99), white) { copyTranscript() }
        button(column, "ذخیره فایل TXT", Color.rgb(54, 82, 99), white) { prepareTxt() }
        button(column, "خروجی Word (DOCX)", Color.rgb(54, 82, 99), white) { prepareDocx() }
        button(column, "خروجی PDF", Color.rgb(54, 82, 99), white) { preparePdf() }
        setContentView(scroll)
    }

    private fun section(parent: LinearLayout, title: String, panel: Int, textColor: Int) {
        val t = TextView(this).apply {
            text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor); setBackgroundColor(panel); gravity = Gravity.RIGHT
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        parent.addView(t, margin(matchWrap(), top = 8, bottom = 10))
    }

    private fun button(parent: LinearLayout, label: String, color: Int, textColor: Int, action: () -> Unit): Button {
        val b = Button(this).apply {
            text = label; setTextColor(textColor); setBackgroundColor(color)
            isAllCaps = false; textSize = 14f; setOnClickListener { action() }
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        parent.addView(b, margin(matchWrap(), bottom = 8))
        return b
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun margin(p: LinearLayout.LayoutParams, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        p.topMargin = dp(top); p.bottomMargin = dp(bottom); return p
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun saveApiKey() {
        val key = apiKeyInput.text.toString().trim()
        if (!key.startsWith("gsk_") || key.length < 20) {
            toast("کلید API واردشده معتبر به نظر نمی‌رسد."); return
        }
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
            val encrypted = cipher.doFinal(key.toByteArray(Charsets.UTF_8))
            prefs.edit()
                .putString("key_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .putString("key_data", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .apply()
            toast("کلید به‌صورت رمزگذاری‌شده ذخیره شد.")
        } catch (e: Exception) { toast("ذخیره امن کلید ناموفق بود: ${e.message}") }
    }

    private fun loadApiKey(): String {
        return try {
            val ivText = prefs.getString("key_iv", null) ?: return ""
            val dataText = prefs.getString("key_data", null) ?: return ""
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(128, Base64.decode(ivText, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(dataText, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun getSecretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun pickAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
        }
        startActivityForResult(intent, PICK_AUDIO)
    }

    @Deprecated("Legacy activity result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK) {
            selectedUri = data?.data
            selectedFile = null
            val name = selectedUri?.let { displayName(it) } ?: "audio"
            status("فایل انتخاب شد: $name")
        } else if (requestCode == CREATE_EXPORT && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val bytes = pendingBytes ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                toast("فایل خروجی ذخیره شد.")
            } catch (e: Exception) { toast("ذخیره فایل ناموفق بود: ${e.message}") }
            pendingBytes = null
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "audio"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    private fun toggleRecording() {
        if (isRecording) { stopRecording(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC); return
        }
        startRecording()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startRecording()
        else if (requestCode == REQUEST_MIC) toast("برای ضبط صدا اجازه میکروفون لازم است.")
    }

    private fun startRecording() {
        try {
            val file = File(cacheDir, "ziaai-${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(128000)
            r.setOutputFile(file.absolutePath)
            r.prepare(); r.start()
            recorder = r; selectedFile = file; selectedUri = null; isRecording = true
            recordButton.text = "پایان ضبط"
            status("در حال ضبط صدا… برای پایان، دوباره دکمه را بزن.")
        } catch (e: Exception) { recorder?.release(); recorder = null; isRecording = false; status("شروع ضبط ناموفق بود: ${e.message}") }
    }

    private fun stopRecording() {
        try {
            recorder?.stop(); recorder?.release(); recorder = null
            isRecording = false; recordButton.text = "شروع ضبط با میکروفون"
            status("ضبط پایان یافت؛ آماده تبدیل است.")
        } catch (e: Exception) {
            recorder?.release(); recorder = null; isRecording = false
            status("ضبط معتبر نبود؛ کمی طولانی‌تر صحبت کن و دوباره امتحان کن.")
        }
    }

    private fun transcribe() {
        if (isRecording) { toast("ابتدا ضبط را متوقف کن."); return }
        val apiKey = loadApiKey()
        if (apiKey.isBlank()) { toast("ابتدا کلید API را وارد و ذخیره کن."); return }
        if (selectedUri == null && selectedFile == null) { toast("ابتدا یک فایل صوتی انتخاب یا ضبط کن."); return }
        val hint = hintInput.text.toString().trim()
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status("در حال آماده‌سازی فایل و اتصال امن…")
        worker.execute {
            var temp: File? = null
            try {
                temp = selectedFile ?: copyUriToCache(selectedUri!!)
                if (temp.length() <= 0L) throw IllegalStateException("فایل صوتی خالی است.")
                if (temp.length() > MAX_FILE_BYTES) throw IllegalStateException("حجم فایل بیشتر از ۱۰۰ مگابایت است.")
                val result = callGroq(apiKey, temp, hint)
                runOnUiThread {
                    transcriptInput.setText(result)
                    progress.isIndeterminate = false; progress.visibility = View.GONE
                    status("تبدیل کامل شد. متن را بازبینی کن؛ تشخیص لهجه و واژه‌های خاص ممکن است نیاز به اصلاح داشته باشد.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.isIndeterminate = false; progress.visibility = View.GONE
                    status("تبدیل ناموفق بود: ${e.message ?: "خطای ناشناخته"}")
                }
            } finally {
                if (temp != null && temp != selectedFile) temp.delete()
            }
        }
    }

    private fun copyUriToCache(uri: Uri): File {
        val extension = when (contentResolver.getType(uri)?.lowercase()) {
            "audio/wav", "audio/x-wav" -> ".wav"
            "audio/mpeg" -> ".mp3"
            "audio/mp4", "audio/m4a", "audio/x-m4a" -> ".m4a"
            "audio/ogg" -> ".ogg"
            "audio/flac" -> ".flac"
            "audio/webm" -> ".webm"
            else -> ".audio"
        }
        val out = File(cacheDir, "upload-${UUID.randomUUID()}$extension")
        contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(out).use { output -> input.copyTo(output) } }
            ?: throw IllegalStateException("امکان خواندن فایل انتخاب‌شده وجود ندارد.")
        return out
    }

    private fun callGroq(key: String, file: File, hint: String): String {
        val boundary = "----ZiaAI${UUID.randomUUID().toString().replace("-", "")}"
        val conn = (URL(GROQ_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; doInput = true
            connectTimeout = 30000; readTimeout = 300000
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json")
            setChunkedStreamingMode(64 * 1024)
        }
        try {
            DataOutputStream(conn.outputStream).use { out ->
                fun field(name: String, value: String) {
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
                    out.write(value.toByteArray(Charsets.UTF_8)); out.writeBytes("\r\n")
                }
                field("model", "whisper-large-v3-turbo")
                field("language", "fa")
                field("response_format", "json")
                val prompt = buildString {
                    append("این فایل به زبان فارسی است. گفتار را دقیق و به همان زبان پیاده‌سازی کن؛ ترجمه نکن. ")
                    append("واژه‌های محاوره‌ای، لهجه، نام‌ها و اصطلاحات را تا حد امکان همان‌طور که گفته شده حفظ کن. ")
                    append("از ساختن کلمات نامفهوم خودداری کن.")
                    if (hint.isNotBlank()) append(" واژه‌های راهنما: $hint")
                }
                field("prompt", prompt)
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"${file.name}\"\r\n")
                out.writeBytes("Content-Type: ${mimeFor(file.name)}\r\n\r\n")
                FileInputStream(file).use { input -> input.copyTo(out, 64 * 1024) }
                out.writeBytes("\r\n--$boundary--\r\n")
                out.flush()
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = try { JSONObject(body).optString("error", body) } catch (_: Exception) { body }
                throw IllegalStateException("پاسخ API ($code): $message")
            }
            val text = JSONObject(body).optString("text", "").trim()
            if (text.isBlank()) throw IllegalStateException("API متنی برنگرداند.")
            return text
        } finally { conn.disconnect() }
    }

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "wav" -> "audio/wav"; "mp3" -> "audio/mpeg"; "m4a", "mp4" -> "audio/mp4"
        "ogg" -> "audio/ogg"; "flac" -> "audio/flac"; "webm" -> "audio/webm"; else -> "application/octet-stream"
    }

    private fun copyTranscript() {
        val text = transcriptInput.text.toString()
        if (text.isBlank()) { toast("هنوز متنی برای کپی وجود ندارد."); return }
        val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clip.setPrimaryClip(ClipData.newPlainText("ZiaAI transcript", text))
        toast("متن کپی شد.")
    }

    private fun prepareTxt() {
        val text = transcriptInput.text.toString()
        if (text.isBlank()) return toast("متنی برای خروجی وجود ندارد.")
        requestExport(text.toByteArray(Charsets.UTF_8), "text/plain", "ziaai-transcript.txt")
    }

    private fun prepareDocx() {
        val text = transcriptInput.text.toString()
        if (text.isBlank()) return toast("متنی برای خروجی وجود ندارد.")
        try {
            val bytes = makeDocx(text)
            requestExport(bytes, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "ziaai-transcript.docx")
        } catch (e: Exception) { toast("ساخت Word ناموفق بود: ${e.message}") }
    }

    private fun makeDocx(text: String): ByteArray {
        val xmlText = text.split("\n").joinToString("") { line ->
            "<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rtl/></w:rPr><w:t xml:space=\"preserve\">${xmlEscape(line)}</w:t></w:r></w:p>"
        }
        val document = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$xmlText<w:sectPr/></w:body></w:document>"""
        val types = """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>"""
        val rels = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""
        val output = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(output).use { zip ->
            fun entry(name: String, value: String) { zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(value.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
            entry("[Content_Types].xml", types); entry("_rels/.rels", rels); entry("word/document.xml", document)
        }
        return output.toByteArray()
    }

    private fun xmlEscape(value: String): String = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    private fun preparePdf() {
        val text = transcriptInput.text.toString()
        if (text.isBlank()) return toast("متنی برای خروجی وجود ندارد.")
        try { requestExport(makePdf(text), "application/pdf", "ziaai-transcript.pdf") }
        catch (e: Exception) { toast("ساخت PDF ناموفق بود: ${e.message}") }
    }

    private fun makePdf(text: String): ByteArray {
        val document = PdfDocument()
        val pageWidth = 595; val pageHeight = 842
        val paint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 12f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
        val usableWidth = pageWidth - 72
        val full = StaticLayout.Builder.obtain(text, 0, text.length, paint, usableWidth)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(true).setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY).build()
        var line = 0; var pageNo = 1
        while (line < full.lineCount) {
            val start = full.getLineStart(line)
            var endLine = line
            while (endLine < full.lineCount && full.getLineBottom(endLine) - full.getLineTop(line) <= pageHeight - 100) endLine++
            if (endLine == line) endLine++
            val end = full.getLineEnd(endLine - 1).coerceAtMost(text.length)
            val chunk = text.substring(start, end)
            val layout = StaticLayout.Builder.obtain(chunk, 0, chunk.length, paint, usableWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(true).setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY).build()
            val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
            page.canvas.drawColor(Color.WHITE)
            page.canvas.save(); page.canvas.translate(36f, 40f); layout.draw(page.canvas); page.canvas.restore()
            document.finishPage(page)
            line = endLine; pageNo++
        }
        val bytes = ByteArrayOutputStream(); document.writeTo(bytes); document.close(); return bytes.toByteArray()
    }

    private fun requestExport(bytes: ByteArray, mime: String, filename: String) {
        pendingBytes = bytes; pendingMime = mime; pendingName = filename
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime
            putExtra(Intent.EXTRA_TITLE, filename)
        }
        startActivityForResult(intent, CREATE_EXPORT)
    }

    private fun status(message: String) { if (::statusText.isInitialized) statusText.text = message }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        if (isRecording) { try { recorder?.stop() } catch (_: Exception) {}; recorder?.release(); recorder = null }
        worker.shutdownNow()
        super.onDestroy()
    }
}
